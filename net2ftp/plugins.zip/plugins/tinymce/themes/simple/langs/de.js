tinyMCE.addI18n('de.simple',{
bold_desc:"Fett (Strg+B)",
italic_desc:"Kursiv (Strg+I)",
underline_desc:"Unterstrichen (Strg+U)",
striketrough_desc:"Durchgestrichen",
bullist_desc:"Unsortierte Liste",
numlist_desc:"Sortierte Liste",
undo_desc:"R\u00FCckg\u00E4ngig (Strg+Z)",
redo_desc:"Wiederholen (Strg+Y)",
cleanup_desc:"Quellcode s\u00E4ubern"
});