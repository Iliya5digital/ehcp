tinyMCE.addI18n('it.simple',{
bold_desc:"Grassetto (Ctrl+B)",
italic_desc:"Corsivo (Ctrl+I)",
underline_desc:"Sottolineato (Ctrl+U)",
striketrough_desc:"Barrato",
bullist_desc:"Lista non ordinata",
numlist_desc:"Lista ordinata",
undo_desc:"Annulla (Ctrl+Z)",
redo_desc:"Ripristina (Ctrl+Y)",
cleanup_desc:"Pulisci codice disordinato"
});