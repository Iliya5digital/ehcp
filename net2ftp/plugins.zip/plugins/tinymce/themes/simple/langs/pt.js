tinyMCE.addI18n('pt.simple',{
bold_desc:"Negrito (Ctrl+B)",
italic_desc:"It\u00E1lico (Ctrl+I)",
underline_desc:"Sublinhado (Ctrl+U)",
striketrough_desc:"Texto riscado",
bullist_desc:"Lista n\u00E3o-ordenada",
numlist_desc:"Lista ordenada",
undo_desc:"Desfazer (Ctrl+Z)",
redo_desc:"Refazer (Ctrl+Y)",
cleanup_desc:"Limpar c\u00F3digo incorreto"
});