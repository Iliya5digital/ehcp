tinyMCE.addI18n('zh.simple',{
bold_desc:"\u7C97\u9AD4(Ctrl+B)",
italic_desc:"\u659C\u9AD4(Ctrl+I)",
underline_desc:"\u5E95\u7DDA (Ctrl+U)",
striketrough_desc:"\u4E2D\u5283\u7DDA",
bullist_desc:"\u6E05\u55AE\u7B26\u865F",
numlist_desc:"\u7DE8\u865F",
undo_desc:"\u64A4\u92B7 (Ctrl+Z)",
redo_desc:"\u6062\u5FA9 (Ctrl+Y)",
cleanup_desc:"\u522A\u9664\u5197\u9918\u78BC"
});