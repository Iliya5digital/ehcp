<?php defined("NET2FTP") or die("Direct access to this location is not allowed."); ?>
<!-- Template /skins/blue/status/status.template.php begin -->
<div id="container">
	<div id="p_ba7428_progress" class="p_ba7428" style="margin-left:auto; margin-right:auto; width:500px; padding-bottom:5px;">
		<table border="0" cellspacing="0" cellpadding="0" style="margin-left: auto; margin-right: auto;">
			<tr>
				<td class="progressBar">
					<div class="progressBarBorder">
					<div id="p_561b57_progressCell0I" class="cellI" style="position:absolute;top:2px;<?php echo __("left"); ?>:2px;">&nbsp;</div>
					<div id="p_561b57_progressCell1I" class="cellI" style="position:absolute;top:2px;<?php echo __("left"); ?>:19px;">&nbsp;</div>
					<div id="p_561b57_progressCell2I" class="cellI" style="position:absolute;top:2px;<?php echo __("left"); ?>:36px;">&nbsp;</div>
					<div id="p_561b57_progressCell3I" class="cellI" style="position:absolute;top:2px;<?php echo __("left"); ?>:53px;">&nbsp;</div>
					<div id="p_561b57_progressCell4I" class="cellI" style="position:absolute;top:2px;<?php echo __("left"); ?>:70px;">&nbsp;</div>
					<div id="p_561b57_progressCell5I" class="cellI" style="position:absolute;top:2px;<?php echo __("left"); ?>:87px;">&nbsp;</div>
					<div id="p_561b57_progressCell6I" class="cellI" style="position:absolute;top:2px;<?php echo __("left"); ?>:104px;">&nbsp;</div>
					<div id="p_561b57_progressCell7I" class="cellI" style="position:absolute;top:2px;<?php echo __("left"); ?>:121px;">&nbsp;</div>
					<div id="p_561b57_progressCell8I" class="cellI" style="position:absolute;top:2px;<?php echo __("left"); ?>:138px;">&nbsp;</div>
					<div id="p_561b57_progressCell9I" class="cellI" style="position:absolute;top:2px;<?php echo __("left"); ?>:155px;">&nbsp;</div>
					<div id="p_561b57_progressCell0A" class="cellA" style="position:absolute;top:2px;<?php echo __("left"); ?>:2px;">&nbsp;</div>
					<div id="p_561b57_progressCell1A" class="cellA" style="position:absolute;top:2px;<?php echo __("left"); ?>:19px;">&nbsp;</div>
					<div id="p_561b57_progressCell2A" class="cellA" style="position:absolute;top:2px;<?php echo __("left"); ?>:36px;">&nbsp;</div>
					<div id="p_561b57_progressCell3A" class="cellA" style="position:absolute;top:2px;<?php echo __("left"); ?>:53px;">&nbsp;</div>
					<div id="p_561b57_progressCell4A" class="cellA" style="position:absolute;top:2px;<?php echo __("left"); ?>:70px;">&nbsp;</div>
					<div id="p_561b57_progressCell5A" class="cellA" style="position:absolute;top:2px;<?php echo __("left"); ?>:87px;">&nbsp;</div>
					<div id="p_561b57_progressCell6A" class="cellA" style="position:absolute;top:2px;<?php echo __("left"); ?>:104px;">&nbsp;</div>
					<div id="p_561b57_progressCell7A" class="cellA" style="position:absolute;top:2px;<?php echo __("left"); ?>:121px;">&nbsp;</div>
					<div id="p_561b57_progressCell8A" class="cellA" style="position:absolute;top:2px;<?php echo __("left"); ?>:138px;">&nbsp;</div>
					<div id="p_561b57_progressCell9A" class="cellA" style="position:absolute;top:2px;<?php echo __("left"); ?>:155px;">&nbsp;</div>
					</div>
				</td>
				<td class="installationProgress" id="p_561b57_installationProgress">
				</td>
			</tr>
		</table>
	</div>
<script type="text/javascript">self.setprogress("p_561b57_",0,"",0); </script>
<!-- Template /skins/blue/status/status.template.php end -->
