<?php defined("NET2FTP") or die("Direct access to this location is not allowed."); ?>
<?php	require_once($net2ftp_globals["application_skinsdir"] . "/blue/status/status.template.php"); ?>
