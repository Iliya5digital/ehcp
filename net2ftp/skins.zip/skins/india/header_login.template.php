<?php defined("NET2FTP") or die("Direct access to this location is not allowed."); ?>
<!-- Template /skins/india/header_login.template.php begin -->
<table border="0" cellpadding="0" cellspacing="0" style="width: 1004px; margin-left: auto; margin-right: auto;">
  <tbody>
    <tr>
      <td style="vertical-align: top; background-color: #e5e5e5;">
        <table border="0" cellpadding="0" cellspacing="0" style="width: 100%;">
          <tbody>
            <tr> 
              <td style="vertical-align: top; text-align: <?php echo __("left"); ?>;">
                <table border="0" cellpadding="0" cellspacing="0" style="width: 1000px; margin-left: auto; margin-right: auto;">
                  <tbody>
                    <tr> 
                      <td style="background-image:url(<?php echo $net2ftp_globals["image_url"]; ?>/backgrounds/headbg.gif); height: 122px; vertical-align: top;">
                        <table border="0" cellpadding="0" cellspacing="0" style="width: 100%;">
                          <tbody>
                            <tr> 
                              <td style="background-image:url(<?php echo $net2ftp_globals["image_url"]; ?>/backgrounds/header.gif); height: 122px; vertical-align: top;">
                                <table border="0" cellpadding="0" cellspacing="0" style="width: 100%;">
                                  <tbody>
                                    <tr> 
                                      <td style="vertical-align: top; width: 45%;">
                                        <table style="height: 110px; width: 100%;" border="0" cellpadding="0" cellspacing="0">
                                          <tbody>
                                            <tr> 
                                              <td style="vertical-align: top; width: 34%; text-align: center;"><img src="<?php echo $net2ftp_globals["image_url"]; ?>/backgrounds/logo.gif" style="height: 104px; width: 145px;" alt="logo" /></td>
                                              <td style="width: 66%;"></td>
                                            </tr>
                                          </tbody>
                                        </table>
                                      </td>
                                      <td class="txtfielddomain" style="text-align: <?php echo __("left"); ?>;">net2ftp - a web based FTP client
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </td>
                    </tr>
<!-- Template /skins/india/header_login.template.php end -->
