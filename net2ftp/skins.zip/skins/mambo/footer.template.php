<?php defined("NET2FTP") or die("Direct access to this location is not allowed."); ?>
<!-- Template /skins/mambo/footer.template.php begin -->
	<div id="poweredby">
		<?php echo __("Powered by"); ?> net2ftp - a web based FTP client<br />
		Add net2ftp to: <a href="http://del.icio.us/post?url=http://www.net2ftp.com">Del.icio.us</a> | 
			<a href="http://digg.com/submit?phase=2&amp;url=http://www.net2ftp.com">Digg</a> | 
			<a href="http://reddit.com/submit?url=http://www.net2ftp.com&amp;title=net2ftp%20-%20a%20web%20based%20FTP%20client">Reddit</a>
	</div>
</div>

<script type="text/javascript">
	function go_to_forums() {
		alert('<?php echo __("You are now taken to the net2ftp forums. These forums are for net2ftp related topics only - not for generic webhosting questions."); ?>');
		document.location = "http://www.net2ftp.org/forums";
	} // end function forums
</script>
<!-- Template /skins/mambo/footer.template.php end -->
