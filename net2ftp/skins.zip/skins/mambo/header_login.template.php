<?php defined("NET2FTP") or die("Direct access to this location is not allowed."); ?>
<!-- Template /skins/blue/header_login.template.php begin -->
<div id="container">
	<div id="head">
		<div id="headleft">
			<a href="http://www.net2ftp.com" target="_blank"><?php echo printPngImage($net2ftp_globals["image_url"] . "/img/logo.png", "net2ftp", "width: 193px; height: 59px; border: 0;"); ?></a>
		</div>
		<div id="headright">
			<h2 style="text-align: <?php echo __("left"); ?>;">net2ftp - A web based FTP client</h2>
		</div>
	</div>
<!-- Template /skins/blue/header_login.template.php end -->
