<?php defined("NET2FTP") or die("Direct access to this location is not allowed."); ?>
<!-- Template /skins/mambo/logout.template.php begin -->

<div class="moduletable">
<h3>net2ftp - a web based FTP client</h3>
</div>

<br /><br />

<p>You have logged out from the FTP server. Go <a href="index.php?option=com_frontpage&Itemid=1">back to the homepage</a>.</p><br />

<?php require_once($net2ftp_globals["application_skinsdir"] . "/" . $net2ftp_globals["skin"] . "/footer.template.php"); ?>
<!-- Template /skins/mambo/logout.template.php end -->
