<?php defined("NET2FTP") or die("Direct access to this location is not allowed."); ?>
<!-- Template /skins/mambo/status.template.php begin -->
<!-- Template /skins/mambo/status.template.php end -->