<?php defined("NET2FTP") or die("Direct access to this location is not allowed."); ?>
<!-- Template /skins/mambo/statusbar.template.php begin -->
<div class="moduletable">
<h3>net2ftp - a web based FTP client</h3>
</div>
<!-- Template /skins/mambo/statusbar.template.php end -->
