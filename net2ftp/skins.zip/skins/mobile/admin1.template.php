<?php require_once($net2ftp_globals["application_skinsdir"] . "/blue/admin1.template.php"); ?>
