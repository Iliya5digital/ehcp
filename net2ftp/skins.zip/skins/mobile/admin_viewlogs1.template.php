<?php defined("NET2FTP") or die("Direct access to this location is not allowed."); ?>
<!-- Template /skins/blue/admin_viewlogs1.template.php begin -->

<input type="hidden" name="input_admin_username" value="<?php echo $input_admin_username; ?>">
<input type="hidden" name="input_admin_password" value="<?php echo $input_admin_password; ?>">

<?php echo $table1; ?>
<br /><br />

<?php echo $table2; ?>
<br /><br />

<?php echo $table3; ?>
<br /><br />

<?php echo $table4; ?>
<br /><br />

<!-- Template /skins/blue/admin_viewlogs1.template.php end -->
