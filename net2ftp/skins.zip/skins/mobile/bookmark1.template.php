<?php defined("NET2FTP") or die("Direct access to this location is not allowed."); ?>
<!-- Template /skins/blue/bookmark1.template.php begin -->

<?php echo __("Add this link to your bookmarks:"); ?> <a href="<?php echo $url; ?>"><?php echo $text; ?></a><br />
<div style="font-size: 80%">
<ul>
	<li> <?php echo __("Internet Explorer: right-click on the link and choose \"Add to Favorites...\""); ?></li>
	<li> <?php echo __("Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\""); ?> </li>
</ul>

<br />
<?php echo __("Note: when you will use this bookmark, a popup window will ask you for your username and password."); ?><br />

<!-- Template /skins/blue/bookmark1.template.php end -->
