<?php defined("NET2FTP") or die("Direct access to this location is not allowed."); ?>
<!-- Template /skins/blue/calculatesize1.template.php begin -->
<?php for ($i=0; $i<sizeof($net2ftp_output["calculatesize"]); $i++) { ?>
<?php		echo $net2ftp_output["calculatesize"][$i]; ?><br />
<?php } // end for ?>
<!-- Template /skins/blue/calculatesize1.template.php end -->
