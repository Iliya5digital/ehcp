<?php defined("NET2FTP") or die("Direct access to this location is not allowed."); ?>
<!-- Template /skins/blue/jupload2.template.php begin -->
<?php for ($i=1; $i<=sizeof($resultMessages); $i++) { ?>
<?php		echo $resultMessages[$i]; ?><br />
<?php } // end for ?>
<!-- Template /skins/blue/jupload2.template.php end -->
