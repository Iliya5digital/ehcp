<?php

// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function setStatus($current, $total, $string) {

// --------------
// This function prints the Javascript which will update the status in the top table
// See also the Javascript function setStatus_js defined in the PHP function printJavascriptFunctions.
// --------------

	return true;

} // End function setStatus

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************

?>