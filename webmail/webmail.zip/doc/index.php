<?php

/**
 * index.php
 *
 * Redirects to the index.html file.
 *
 * @copyright &copy; 1999-2009 The SquirrelMail Project Team
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * @version $Id: index.php 13488 2009-03-29 00:13:34Z pdontthink $
 * @package squirrelmail
 */

header('Location: index.html');

