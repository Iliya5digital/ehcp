<?
$dbhost='localhost';
$dbusername='ehcp';
$dbpass='444';
$dbname='ehcp';
?>
